public class DecisionSystem {
    public static class PurchaseResult {
        public final String productName;
        public final int size, quantity;
        public final double subtotal, discountPercent, total;
        public final String message;
        public PurchaseResult(String productName, int size, int quantity, double subtotal,
                              double discountPercent, double total, String message) {
            this.productName=productName; this.size=size; this.quantity=quantity;
            this.subtotal=subtotal; this.discountPercent=discountPercent; this.total=total; this.message=message;
        }
    }
    public static PurchaseResult calculate(String product, int size, int quantity, String customerType) {
        String name; double price;
        switch(product) {
            case "curry": name="Under Armour Curry 11"; price=69000; break;
            case "kyrie": name="Nike Kyrie Infinity"; price=76000; break;
            case "freak": name="Nike Zoom Freak 5"; price=72000; break;
            case "lebron": name="Nike LeBron 21"; price=89000; break;
            case "jordan": name="Air Jordan XXXVIII"; price=94000; break;
            case "kd": name="Nike KD 16"; price=84000; break;
            case "harden": name="Adidas Harden Vol. 7"; price=79000; break;
            case "mb": name="Puma MB.03"; price=73000; break;
            case "anta": name="ANTA Shock Wave 5"; price=68000; break;
            case "li ning": name="Li-Ning Wade 10"; price=97000; break;
            default: throw new IllegalArgumentException("Неизвестный товар.");
        }
        double subtotal=price*quantity;
        boolean vip="vip".equals(customerType);
        double discount;
        if(subtotal>=100000 && vip) discount=20;
        else if(subtotal>=100000) discount=15;
        else if(subtotal>=50000 && vip) discount=10;
        else if(subtotal>=50000 || vip) discount=5;
        else discount=0;
        double total=subtotal-subtotal*discount/100.0;
        String message=discount>0?"Скидка применена. Спасибо за покупку в FLYUP!":"Спасибо за выбор FLYUP!";
        return new PurchaseResult(name,size,quantity,subtotal,discount,total,message);
    }
}
