public class Validation {
    public static String validatePurchase(String name, String product,
                                          String sizeText, String quantityText) {
        if (name == null || name.isBlank()) {
            return "Введите имя покупателя.";
        }
        if (product == null || product.isBlank()) {
            return "Выберите модель кроссовок.";
        }

        int size;
        int quantity;

        try {
            size = Integer.parseInt(sizeText);
        } catch (NumberFormatException e) {
            return "Размер должен быть целым числом.";
        }

        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            return "Количество должно быть целым числом.";
        }

        if (size < 35 || size > 45) {
            return "Размер должен быть в диапазоне от 35 до 45.";
        }
        if (quantity < 1 || quantity > 20) {
            return "Количество должно быть от 1 до 20.";
        }
        return null;
    }
}
