import java.util.Locale;

public class Menu {
    private static final String STYLE = """
      <style>
      *{box-sizing:border-box}html{scroll-behavior:smooth}
      body{margin:0;background:#090b0d;color:#f4f1eb;font-family:Arial,sans-serif}
      body:before{content:"";position:fixed;inset:0;z-index:-2;background:linear-gradient(90deg,#080a0deF,#080a0dba,#080a0deF),url('https://images.unsplash.com/photo-1546519638-68e109498ffc?auto=format&fit=crop&w=2000&q=85') center/cover}
      header{height:78px;padding:0 5%;display:flex;align-items:center;justify-content:space-between;background:#080a0deF;border-bottom:1px solid #ffffff20;position:sticky;top:0;z-index:5;backdrop-filter:blur(12px)}
      .brand{display:flex;align-items:center;gap:12px;color:#f4a64a;text-decoration:none;font-weight:900;font-size:25px;letter-spacing:3px}
      .logo{width:43px;height:43px}.nav{display:flex;align-items:center;gap:24px}.nav a{color:#ddd;text-decoration:none;font-size:13px}.nav a:hover{color:#f3a64a}
      .cartBtn,.btn{border:0;border-radius:8px;background:#f1a044;color:#17120c;padding:12px 17px;font-weight:800;cursor:pointer;text-decoration:none;display:inline-block}
      .cartBtn span{background:#161616;color:#f6ad59;border-radius:20px;padding:3px 7px;margin-left:5px}
      main{max-width:1500px;margin:28px auto;padding:0 22px}
      .hero{border:1px solid #ffffff20;border-radius:20px;padding:38px 42px;margin-bottom:25px;background:linear-gradient(100deg,#101316f5,#191a19c9);box-shadow:0 15px 45px #0008}
      .eyebrow{color:#f2a04a;letter-spacing:3px;text-transform:uppercase;font-size:11px;font-weight:bold}
      h1{font-size:clamp(35px,5vw,58px);margin:12px 0;line-height:1.02}h2{margin:0 0 16px}
      .hero p{color:#c6c2bb;line-height:1.7;max-width:700px}
      .shop-layout{display:grid;grid-template-columns:190px minmax(0,1fr) 190px;gap:18px;align-items:stretch}
      .side-ad{min-height:520px;border:1px solid #ffffff20;border-radius:16px;overflow:hidden;position:relative;background:#181818;display:flex;align-items:end;text-decoration:none;color:white;box-shadow:0 12px 35px #0008}
      .side-ad img{position:absolute;width:100%;height:100%;object-fit:cover;inset:0;opacity:.65}
      .side-ad:after{content:"";position:absolute;inset:0;background:linear-gradient(0deg,#070809 0%,transparent 85%)}
      .ad-copy{position:relative;z-index:1;padding:17px}.ad-copy small{color:#f2a04a;letter-spacing:2px}.ad-copy b{display:block;font-size:22px;margin:8px 0}.ad-copy span{font-size:12px;color:#ddd}
      .catalog{min-width:0}.category{margin:0 0 24px;padding:20px;border:1px solid #ffffff20;border-radius:16px;background:#101316eF}
      .category-head{display:flex;justify-content:space-between;align-items:end;margin-bottom:15px}.category-head p{color:#aaa;font-size:12px;margin:0}
      .products{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:13px}
      .product{background:#1a1d20;border:1px solid #ffffff18;border-radius:12px;overflow:hidden;transition:.2s}
      .product:hover{transform:translateY(-3px);border-color:#f1a04499}
      .product img{width:100%;height:175px;object-fit:cover;display:block;background:#272727}
      .info{padding:13px}.tag{font-size:10px;text-transform:uppercase;letter-spacing:1px;color:#f2a04a}
      .info b{display:block;margin:7px 0;font-size:14px}.desc{color:#aaa;font-size:11px;min-height:28px;line-height:1.4}
      .price{color:#f3aa56;font-weight:bold;margin:10px 0}.add{width:100%;border:1px solid #f1a044;background:transparent;color:#f1a044;border-radius:7px;padding:9px;cursor:pointer;font-weight:bold}
      .add:hover{background:#f1a044;color:#15110c}
      footer{margin-top:45px;background:#080a0df5;border-top:1px solid #ffffff20;padding:35px 6% 20px;color:#bdbbb5}
      .footgrid{max-width:1300px;margin:auto;display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:25px}
      footer h3,footer b{color:#f3a34c}footer p,footer a{font-size:12px;line-height:1.8;color:#aaa;text-decoration:none;display:block}
      .copyright{text-align:center;border-top:1px solid #ffffff18;margin-top:25px;padding-top:18px;font-size:11px}
      .modal{display:none;position:fixed;inset:0;background:#000b;z-index:10;align-items:center;justify-content:center;padding:16px}
      .modal.open{display:flex}.panel{background:#15191c;border:1px solid #ffffff30;border-radius:16px;width:min(560px,100%);max-height:92vh;overflow:auto;padding:24px;box-shadow:0 20px 70px #000}
      .panel-top{display:flex;justify-content:space-between;align-items:center}.close{background:transparent;border:0;color:white;font-size:27px;cursor:pointer}
      .cart-row{display:grid;grid-template-columns:1fr auto;gap:8px;border-bottom:1px solid #ffffff20;padding:13px 0;font-size:13px}
      .cart-row small{color:#aaa;display:block;margin-top:5px}.qty{display:flex;gap:7px;align-items:center}.qty button{background:#292e32;color:#fff;border:0;border-radius:5px;padding:5px 9px;cursor:pointer}
      .total{font-size:20px;font-weight:bold;color:#f3a34c;text-align:right;margin:18px 0}
      label{display:block;font-size:12px;font-weight:bold;margin:12px 0 6px}input,select,textarea{width:100%;padding:11px;border-radius:7px;border:1px solid #ffffff2a;background:#252a2e;color:#fff}
      .checkout{width:100%;margin-top:14px}.note{font-size:11px;color:#aaa;line-height:1.5}
      .result{background:#15191c;border:1px solid #ffffff22;border-left:4px solid #f1a044;padding:28px;border-radius:14px}
      @media(max-width:1050px){.shop-layout{grid-template-columns:145px minmax(0,1fr) 145px}.side-ad{min-height:440px}.footgrid{grid-template-columns:1fr 1fr}}
      @media(max-width:720px){header{padding:0 4%;height:68px}.nav{gap:10px}.nav a{display:none}.brand{font-size:20px}.shop-layout{grid-template-columns:1fr}.side-ad{min-height:190px}.side-ad img{object-position:center 35%}.products{grid-template-columns:repeat(2,minmax(0,1fr))}.hero{padding:27px 23px}.category{padding:14px}}
      </style>
      """;

    private static String logo() {
        return """
          <svg class="logo" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M18 20H82M24 20L30 42H70L76 20" stroke="#F3A34C" stroke-width="5" stroke-linecap="round"/>
            <path d="M30 42L36 76L50 89L64 76L70 42M36 76L50 42L64 76M30 42L64 76M70 42L36 76" stroke="#F3A34C" stroke-width="3.5" stroke-linejoin="round"/>
            <path d="M50 5V18M43 11H57" stroke="#F3A34C" stroke-width="4" stroke-linecap="round"/>
          </svg>
          """;
    }

    private static String page(String title, String content) {
        return """
          <!doctype html><html lang="ru"><head><meta charset="UTF-8">
          <meta name="viewport" content="width=device-width,initial-scale=1.0">
          <title>%s | FLYUP</title>%s</head><body>
          <header><a class="brand" href="/">%s FLYUP</a><nav class="nav"><a href="/">Магазин</a><a href="/report">О магазине</a>
          <button class="cartBtn" onclick="openCart()">Корзина <span id="cartCount">0</span></button></nav></header>
          <main>%s</main>%s
          </body></html>
          """.formatted(title, STYLE, logo(), content, FOOTER);
    }

    private static final String FOOTER = """
      <footer><div class="footgrid">
        <div><div class="brand">🏀 FLYUP</div><p>Магазин баскетбольной обуви и уличного стиля. Подбирай свою пару, выходи на площадку и играй в своём ритме.</p></div>
        <div><b>Покупателям</b><a href="/">Каталог</a><a href="#" onclick="openCart();return false">Корзина и заказ</a><a href="#delivery">Доставка</a><a href="#returns">Возврат</a></div>
        <div><b>Поддержка</b><p>Почта: support@flyup.kz</p><p>Телефон: +7 (700) 123-45-67</p><p>Ежедневно: 10:00–20:00</p></div>
        <div><b>Информация</b><p>Оплата при получении или переводом по согласованию.</p><p id="delivery">Доставка по Казахстану.</p><p id="returns">Условия возврата уточняйте у поддержки.</p></div>
      </div><div class="copyright">© 2026 FLYUP SNEAKER STORE. Учебный демонстрационный проект.</div></footer>
      """;

    private static String card(String key, String name, String desc, String price, String category, String img) {
        return """
          <article class="product"><img src="%s" alt="%s">
          <div class="info"><span class="tag">%s</span><b>%s</b><div class="desc">%s</div>
          <div class="price">%s ₸</div><button class="add" onclick="addToCart('%s')">В корзину +</button></div></article>
          """.formatted(img, name, category, name, desc, price, key);
    }

    public static String renderHome() {
        String catalog = """
          <section class="category"><div class="category-head"><div><span class="eyebrow">01 / Speed & agility</span><h2>Лёгкие модели</h2></div><p>Для быстрых игроков</p></div><div class="products">
          """ +
          card("curry","Under Armour Curry 11","Лёгкая посадка и цепкое сцепление","69 000","Лёгкие",
            "/images/curry.jpg") +
          card("kyrie","Nike Kyrie Infinity","Манёвренность и контроль на резких поворотах","76 000","Лёгкие",
            "/images/kyrie.jpg") +
          card("freak","Nike Zoom Freak 5","Отзывчивая амортизация для динамичной игры","72 000","Лёгкие",
            "/images/freak.jpg") +
          """
          </div></section><section class="category"><div class="category-head"><div><span class="eyebrow">02 / Pro performance</span><h2>Профессиональные игровые</h2></div><p>Поддержка и амортизация</p></div><div class="products">
          """ +
          card("lebron","Nike LeBron 21","Стабильность и мощная амортизация","89 000","Игровые",
            "/images/lebron.jpg") +
          card("jordan","Air Jordan XXXVIII","Плотная фиксация и контроль стопы","94 000","Игровые",
            "/images/jordan.jpg") +
          card("kd","Nike KD 16","Баланс комфорта и отзывчивости","84 000","Игровые",
            "/images/kd.jpg") +
          card("harden","Adidas Harden Vol. 7","Уверенное сцепление для смены направления","79 000","Игровые",
            "/images/harden.jpg") +
          """
          </div></section><section class="category"><div class="category-head"><div><span class="eyebrow">03 / Signature brands</span><h2>Брендовые коллекции</h2></div><p>Стиль за пределами площадки</p></div><div class="products">
          """ +
          card("mb","Puma MB.03","Яркий дизайн и комфорт для игры","73 000","Брендовые",
            "/images/mb03.jpg") +
          card("anta","ANTA Shock Wave 5","Игровая модель с выразительным силуэтом","68 000","Брендовые",
            "/images/anta.jpg") +
          card("li ning","Li-Ning Wade 10","Поддержка и фирменный дизайн","97 000","Брендовые",
            "/images/lining.jpg") +
          """
          </div></section>
          """;

        String content = """
          <section class="hero"><span class="eyebrow">Basketball is a lifestyle</span>
          <h1>OWN THE COURT.<br>OWN YOUR GAME.</h1>
          <p>FLYUP — баскетбольные кроссовки под заказ. 10 моделей, три направления и твой следующий шаг на площадке. Выбери пару и добавь её в корзину.</p></section>
          <div class="shop-layout">
            <a class="side-ad" href="#catalog"><img src="/images/iverson-shirt.jpg" alt="Баскетбольная форма">
              <div class="ad-copy"><small>LEGEND SERIES</small><b>ALLEN IVERSON</b><span>Футболка в стиле легенды №3</span></div></a>
            <div class="catalog" id="catalog">%s</div>
            <a class="side-ad" href="#catalog"><img src="/images/kyrie-banner.jpg" alt="Баскетбольная площадка">
              <div class="ad-copy"><small>PLAYMAKER SERIES</small><b>KYRIE IRVING</b><span>Футболка в стиле мастера дриблинга</span></div></a>
          </div>
          """.formatted(catalog);
        return page("Баскетбольный магазин", content + CART_MODAL + CART_SCRIPT);
    }

    private static final String CART_MODAL = """
      <div class="modal" id="cartModal" onclick="if(event.target===this)closeCart()"><div class="panel">
        <div class="panel-top"><h2>Твоя корзина</h2><button class="close" onclick="closeCart()">×</button></div>
        <div id="cartItems"></div><div class="total" id="cartTotal">Итого: 0 ₸</div>
        <form method="POST" action="/checkout" id="checkoutForm">
          <input type="hidden" name="cartData" id="cartData">
          <h3>Оформление заказа</h3>
          <label>Имя и фамилия</label><input name="name" required placeholder="Как к вам обращаться">
          <label>Телефон</label><input name="phone" type="tel" required placeholder="+7 700 000 00 00">
          <label>Адрес доставки</label><textarea name="address" required rows="2" placeholder="Город, улица, дом, квартира"></textarea>
          <label>Размер обуви для каждой пары выбирается при добавлении</label>
          <label>Способ оплаты</label><select name="payment"><option>При получении</option><option>Перевод по согласованию с менеджером</option></select>
          <p class="note">Это демонстрационный checkout: банковские данные на сайте не вводятся. После отправки заказ будет показан как заявка для подтверждения менеджером.</p>
          <button class="btn checkout" type="submit">Подтвердить заказ</button>
        </form>
      </div></div>
      """;

    private static final String CART_SCRIPT = """
      <script>
      const PRODUCTS={
        curry:{name:'Under Armour Curry 11',price:69000},kyrie:{name:'Nike Kyrie Infinity',price:76000},
        freak:{name:'Nike Zoom Freak 5',price:72000},lebron:{name:'Nike LeBron 21',price:89000},
        jordan:{name:'Air Jordan XXXVIII',price:94000},kd:{name:'Nike KD 16',price:84000},
        harden:{name:'Adidas Harden Vol. 7',price:79000},mb:{name:'Puma MB.03',price:73000},
        anta:{name:'ANTA Shock Wave 5',price:68000},'li ning':{name:'Li-Ning Wade 10',price:97000}
      };
      let cart=JSON.parse(localStorage.getItem('flyupCart')||'{}');
      function saveCart(){localStorage.setItem('flyupCart',JSON.stringify(cart));renderCart()}
      function addToCart(key){
        const size=prompt('Выбери размер обуви (35–45):','42');
        if(size===null)return;const n=Number(size);
        if(!Number.isInteger(n)||n<35||n>45){alert('Размер должен быть от 35 до 45');return}
        const id=key+'_'+n;if(!cart[id])cart[id]={key:key,size:n,qty:0};cart[id].qty++;
        saveCart();alert('Добавлено в корзину!');
      }
      function changeQty(id,delta){cart[id].qty+=delta;if(cart[id].qty<=0)delete cart[id];saveCart()}
      function removeItem(id){delete cart[id];saveCart()}
      function renderCart(){
        let count=0,total=0,html='';
        Object.keys(cart).forEach(id=>{const item=cart[id],p=PRODUCTS[item.key];if(!p)return;
          count+=item.qty;total+=p.price*item.qty;
          html+=`<div class="cart-row"><div><b>${p.name}</b><small>Размер: ${item.size} · ${p.price.toLocaleString('ru-RU')} ₸ за пару</small>
          <button type="button" onclick="removeItem('${id}')" style="margin-top:7px;background:none;border:0;color:#e99a3d;cursor:pointer">Удалить</button></div>
          <div class="qty"><button type="button" onclick="changeQty('${id}',-1)">−</button>${item.qty}<button type="button" onclick="changeQty('${id}',1)">+</button></div></div>`;
        });
        document.getElementById('cartCount').textContent=count;
        document.getElementById('cartItems').innerHTML=html||'<p class="note">Корзина пока пуста. Добавь свою первую пару!</p>';
        document.getElementById('cartTotal').textContent='Итого: '+total.toLocaleString('ru-RU')+' ₸';
        document.getElementById('cartData').value=Object.values(cart).map(i=>i.key+':'+i.qty+':'+i.size).join(';');
        document.querySelector('#checkoutForm button').disabled=count===0;
        document.querySelector('#checkoutForm button').style.opacity=count===0?'.45':'1';
      }
      function openCart(){document.getElementById('cartModal').classList.add('open');renderCart()}
      function closeCart(){document.getElementById('cartModal').classList.remove('open')}
      document.getElementById('checkoutForm').addEventListener('submit',e=>{
        if(Object.keys(cart).length===0){e.preventDefault();alert('Корзина пуста');return}
        document.getElementById('cartData').value=Object.values(cart).map(i=>i.key+':'+i.qty+':'+i.size).join(';');
      });
      renderCart();
      </script>
      """;

    public static String renderOrderConfirmation(String name, String phone, String address,
                                                  String payment, String items, double total) {
        String content = """
          <section class="result"><span class="eyebrow">FLYUP / ORDER</span><h1>Заявка оформлена!</h1>
          <p>Спасибо, <b>%s</b>! Ваша заявка принята для подтверждения менеджером.</p>
          <h2>Состав заказа</h2><ul>%s</ul><h2>Итого: %s ₸</h2>
          <p><b>Телефон:</b> %s</p><p><b>Адрес:</b> %s</p><p><b>Оплата:</b> %s</p>
          <p class="note">Это учебная версия магазина: заказ не отправляется в реальную службу доставки и оплата не списывается.</p>
          <a class="btn" href="/">Вернуться в магазин</a></section>
          """.formatted(escape(name), items, money(total), escape(phone), escape(address), escape(payment));
        return page("Заявка оформлена", content);
    }

    public static String pageForReport(String content) { return page("О магазине", content); }
    public static String renderPurchaseResult(String name, DecisionSystem.PurchaseResult r) {
        return renderOrderConfirmation(name, "—", "—", "При получении",
            "<li>"+escape(r.productName)+" — размер "+r.size+", "+r.quantity+" шт.</li>", r.total);
    }
    public static String renderResult(String title, String message, boolean error) {
        return page(title, "<section class='result'><h1>"+escape(title)+"</h1><p>"+escape(message)+
            "</p><a class='btn' href='/'>Вернуться в магазин</a></section>");
    }
    static String money(double value) { return String.format(Locale.US, "%,.0f", value).replace(',', ' '); }
    static String escape(String value) {
        if (value == null) return "";
        return value.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
            .replace("\"","&quot;").replace("'","&#39;");
    }
}
