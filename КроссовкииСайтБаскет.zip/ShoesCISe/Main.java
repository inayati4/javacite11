import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class Main {
    private static final int PORT = 8081;

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
        // Раздача пользовательских изображений из папки ShoesCISe/images
        server.createContext("/images", exchange -> serveImage(exchange));

        server.createContext("/", exchange -> {
            if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) send(exchange, 200, Menu.renderHome());
            else send(exchange, 405, "Method Not Allowed");
        });

        server.createContext("/checkout", exchange -> {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                send(exchange, 405, "Method Not Allowed"); return;
            }
            Map<String, String> form = parseForm(new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
            String name = form.getOrDefault("name", "").trim();
            String phone = form.getOrDefault("phone", "").trim();
            String address = form.getOrDefault("address", "").trim();
            String payment = form.getOrDefault("payment", "При получении");
            String cartData = form.getOrDefault("cartData", "");
            if (name.isBlank() || phone.isBlank() || address.isBlank() || cartData.isBlank()) {
                send(exchange, 400, Menu.renderResult("Не удалось оформить заказ",
                    "Проверьте имя, телефон, адрес и наличие товаров в корзине.", true));
                return;
            }
            StringBuilder lines = new StringBuilder();
            double total = 0;
            try {
                for (String item : cartData.split(";")) {
                    String[] parts = item.split(":");
                    if (parts.length != 3) throw new IllegalArgumentException();
                    String key = parts[0];
                    int qty = Integer.parseInt(parts[1]);
                    int size = Integer.parseInt(parts[2]);
                    if (qty < 1 || qty > 20 || size < 35 || size > 45) throw new IllegalArgumentException();
                    DecisionSystem.PurchaseResult p = DecisionSystem.calculate(key, size, qty, "regular");
                    total += p.total;
                    lines.append("<li>").append(Menu.escape(p.productName)).append(" — размер ")
                        .append(size).append(", ").append(qty).append(" шт. — ")
                        .append(Menu.money(p.total)).append(" ₸</li>");
                }
            } catch (Exception ex) {
                send(exchange, 400, Menu.renderResult("Ошибка корзины", "Обновите корзину и попробуйте ещё раз.", true));
                return;
            }
            send(exchange, 200, Menu.renderOrderConfirmation(name, phone, address, payment, lines.toString(), total));
        });

        server.createContext("/report", exchange -> send(exchange, 200, Report.render()));
        server.setExecutor(null);
        server.start();
        System.out.println("==================================");
        System.out.println(" FLYUP запущен: http://localhost:" + PORT);
        System.out.println(" Открой эту ссылку в браузере. Для остановки нажми Ctrl + C.");
        System.out.println("==================================");
    }

    private static void serveImage(HttpExchange exchange) throws IOException {
        String requestPath = exchange.getRequestURI().getPath();
        String fileName = requestPath.substring("/images".length()).replaceFirst("^/", "");

        // Разрешаем только простые имена файлов, чтобы нельзя было читать файлы вне images.
        if (fileName.isBlank() || !fileName.matches("[a-zA-Z0-9._-]+")) {
            exchange.sendResponseHeaders(400, -1);
            exchange.close();
            return;
        }

        Path imagesDir = Path.of("images").toAbsolutePath().normalize();
        Path file = imagesDir.resolve(fileName).normalize();
        if (!file.startsWith(imagesDir) || !Files.isRegularFile(file)) {
            exchange.sendResponseHeaders(404, -1);
            exchange.close();
            return;
        }

        String type = Files.probeContentType(file);
        if (type == null) {
            String lower = fileName.toLowerCase();
            if (lower.endsWith(".png")) type = "image/png";
            else if (lower.endsWith(".webp")) type = "image/webp";
            else if (lower.endsWith(".gif")) type = "image/gif";
            else type = "image/jpeg";
        }

        byte[] bytes = Files.readAllBytes(file);
        exchange.getResponseHeaders().set("Content-Type", type);
        exchange.getResponseHeaders().set("Cache-Control", "no-cache");
        exchange.sendResponseHeaders(200, bytes.length);
        exchange.getResponseBody().write(bytes);
        exchange.close();
    }

    private static Map<String, String> parseForm(String body) {
        Map<String, String> values = new HashMap<>();
        if (body == null || body.isEmpty()) return values;
        for (String pair : body.split("&")) {
            String[] parts = pair.split("=", 2);
            String key = URLDecoder.decode(parts[0], StandardCharsets.UTF_8);
            String value = parts.length > 1 ? URLDecoder.decode(parts[1], StandardCharsets.UTF_8) : "";
            values.put(key, value);
        }
        return values;
    }

    static void send(HttpExchange exchange, int status, String html) throws IOException {
        byte[] bytes = html.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
        exchange.getResponseHeaders().set("Cache-Control", "no-store");
        exchange.sendResponseHeaders(status, bytes.length);
        exchange.getResponseBody().write(bytes);
        exchange.close();
    }
}
