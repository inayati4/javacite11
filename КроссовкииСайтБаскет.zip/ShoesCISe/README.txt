FLYUP — баскетбольный магазин (Java HttpServer)

ЗАПУСК
1. Откройте папку ShoesCISe в VS Code.
2. Откройте терминал в этой папке.
3. Выполните:
   javac Main.java Menu.java DecisionSystem.java Validation.java Report.java
   java Main
4. Откройте в браузере:
   http://localhost:8081

КАК ДОБАВИТЬ СВОИ ФОТО
Все фотографии положите в папку images (она находится рядом с Main.java).
Названия файлов должны быть точно такими:

Фон сайта:
  background.jpg

Фотографии кроссовок:
  curry.jpg       — Under Armour Curry 11
  kyrie.jpg       — Nike Kyrie Infinity
  freak.jpg       — Nike Zoom Freak 5
  lebron.jpg      — Nike LeBron 21
  jordan.jpg      — Air Jordan XXXVIII
  kd.jpg          — Nike KD 16
  harden.jpg      — Adidas Harden Vol. 7
  mb03.jpg        — Puma MB.03
  anta.jpg        — ANTA Shock Wave 5
  lining.jpg      — Li-Ning Wade 10

Боковые изображения:
  iverson-shirt.jpg — левый баннер
  kyrie-banner.jpg  — правый баннер

Можно использовать .jpg, .png или .webp, но расширение в имени файла
должно совпадать с тем, которое указано в Menu.java. Если ваши фото PNG,
переименуйте ссылки в Menu.java на, например, /images/curry.png.

ВАЖНО
- Интернет для фотографий больше не нужен: сайт загружает картинки из локальной папки images.
- Не удаляйте папку images и не меняйте имена файлов, если не обновили пути в Menu.java.
- Если фотографий пока нет, изображения будут пустыми до добавления файлов.
- Корзина хранится в браузере. Это демонстрационный учебный заказ: реальные платежи
  и сохранение заказов в базе данных не реализованы.
